<?php

#Disable direct access.
if (!strcasecmp(basename($_SERVER['SCRIPT_NAME']), basename( __FILE__ ))) die ('kwaheri rafiki!');

$LANG['PT_BR_NAME'] = 'Portugues Brasil';
$LANG['US_NAME'] = 'English';
$LANG['NL_NAME'] = 'Nederlands';
$LANG['FR_NAME'] = 'Français ';
 
?>